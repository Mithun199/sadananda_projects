from controller.build_maze import Maze
from model.resource_constants import Maze1

def main():
    maze = Maze(Maze1)

    maze.build_maze()    

    maze.solve_maze()
    
    
if __name__ == '__main__':
    main()
