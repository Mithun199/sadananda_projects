from model import *

def get_next_cell_details(exit_wall , row , col):
    
    '''
        This method will return the next cell details and it's entry WALL Name
        
        Args:
            exit_wall : Enum = Which says from which side of the current cell has the door opening to next cell
                               Exiting from NORTH door to next cell SOUTH door
            row : int  = row number of the current cell            
            col : int  = column number of the current cell
        Returns:
            tuple : returns the tuple which contains next cell row and column details along with ENTRY WALL Name of the next cell
        
    '''
    
    print(row , col)
    
    EAST_EXIT   = lambda row , col : (row , col + 1)
    WEST_EXIT   = lambda row , col : (row , col - 1)
    NORTH_EXIT  = lambda row , col : (row - 1 , col)
    SOUTH_EXIT  = lambda row , col : (row + 1 , col)
    
    if exit_wall == CellEnum.NORTH.value:
        return (CellEnum.SOUTH , NORTH_EXIT(row , col))
        
    if exit_wall == CellEnum.SOUTH.value:
        return (CellEnum.NORTH , SOUTH_EXIT(row , col))
        
    if exit_wall == CellEnum.EAST.value:
        return (CellEnum.WEST , EAST_EXIT(row , col))
        
    if exit_wall == CellEnum.WEST.value:        
        return (CellEnum.EAST , WEST_EXIT(row , col))

    return None

def get_wall_cordinates(cell):
    
    '''
        This function will return the co-ordinates of a cell for all the four corners
        
        Args
            cell : cell object of the maze
            
        return 
            wall_cordinates : tuple which has all 4 corner co-ordinates details

    '''
    
    wall_cordinates = []
    wall_points = {
                    CellEnum.NORTH.value : (CellCorner.TOP_LEFT    , CellCorner.TOP_RIGHT) ,
                    CellEnum.EAST.value  : (CellCorner.TOP_RIGHT   , CellCorner.BOTTOM_RIGHT) ,
                    CellEnum.WEST.value  : (CellCorner.BOTTOM_LEFT , CellCorner.TOP_LEFT) ,
                    CellEnum.SOUTH.value : (CellCorner.BOTTOM_LEFT , CellCorner.BOTTOM_RIGHT) 

                    }
    for w in wall_points.values():
        x_y    = get_co_cordinates(w[0] , cell.row , cell.col)
        x1_y1  = get_co_cordinates(w[1] , cell.row , cell.col)

        wall_cordinates.append((x_y , x1_y1))
    

    return wall_cordinates

def get_co_cordinates(cell_corner , row , col):

    '''
        This method will return the next cell details and it's entry WALL Name
        
        Args:
            cell_corner : Enum = Which says from which side of the current cell has the door opening to next cell
                                 Exiting from NORTH door to next cell SOUTH door
            row : int  = row number of the current cell
            
            col : int  = column number of the current cell
        Returns:
            tuple : returns the tuple which contains next cell row and column details along with ENTRY WALL Name of the next cell
        
    '''
        
    
    x = (MazeBoardEnum.INITIAL_X.value * col) + MazeBoardEnum.INITIAL_X.value
    y = (MazeBoardEnum.INITIAL_X.value * row) + MazeBoardEnum.INITIAL_Y.value
                        
    if cell_corner.value == CellCorner.TOP_LEFT.value:
        return x , y
        
    elif cell_corner.value == CellCorner.TOP_RIGHT.value:
        x = x + MazeBoardEnum.CELL_WIDTH_HEIGHT.value            
    
    elif cell_corner.value == CellCorner.BOTTOM_LEFT.value:            
        y = y + MazeBoardEnum.CELL_WIDTH_HEIGHT.value        
    
    elif cell_corner.value == CellCorner.BOTTOM_RIGHT.value:
        x = x + MazeBoardEnum.CELL_WIDTH_HEIGHT.value
        y = y + MazeBoardEnum.CELL_WIDTH_HEIGHT.value
        
    return x , y
