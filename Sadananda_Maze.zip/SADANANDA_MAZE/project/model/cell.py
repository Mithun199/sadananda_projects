'''
    Cell -->
            Representes each cell in the maze boards which constitues the wall
            Wall of the cell is used for traversing the path to the next cell untill the exit found
'''

class Cell:
    PATH_FOUND = False
    
    def __init__(self , row , col , N_E_W_S=0):

        '''
        (row , col) both indicate cell number in the square board
            N_E_W_S is an CELL WALL
            if, N_E_W_S = 0xF (1 1 1 1) all the wall are present which means cell is closed
        '''
        
        self.row = row
        self.col = col
        self.N_E_W_S = N_E_W_S
        # to have copy of wall so that we can modify while traversion      
        self.N_E_W_S_covered = 0      
    
    @property
    def N_E_W_S(self)-> int:
        return self._N_E_W_S

    @N_E_W_S.setter
    def N_E_W_S(self , n_e_w_s):
        self._N_E_W_S = n_e_w_s
        self.N_E_W_S_covered = n_e_w_s
