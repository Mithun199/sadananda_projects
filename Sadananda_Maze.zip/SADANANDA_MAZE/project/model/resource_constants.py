from enum import Enum

class MazeBoardEnum(Enum):
    '''
    CELL DETAILS IN THE MAZE BOARD 
    '''

    MAZE_WITDH_HEIGTH = "1500x1500"
    MAZE_LINE_COLOR = 'black'
    MAZE_PATH_COLOR = 'red'
    CANVAS_WIDTH = 1500
    CANVAS_HEIGTH = 1500
    MAZE_LINE_WIDTH = 1    
    CELL_WIDTH_HEIGHT = 50   
    INITIAL_X = 50
    INITIAL_Y = 40              
    MAZE_PATH_INITIAL_X = 600    
    
class ShapeEnum(Enum):

    # different shapes for drawing
    SQUARE = 'SQUARE'
    RECTANGLE = 'RECTANGLE'
    LINE = 'LINE'

class CellCorner(Enum):


    '''
    Below enum represents cell corners.
    
    This Enum corners Values can be used as a input for drawing the wall for each cell using drawline in tkinter.
    
    West  wall (W) |   --> Bottom Left -> Top Left
    East  wall (E) |   --> Top Right -> Bottom Right
    North wall (N) --  --> Top Left -> Top Right
    South wall (S) __  --> Bottom Left -> Bottom Right
    
    
    Top left    Top Right
        \     /
           __
          |__|
        /     \
    Bottom     Bottom
     left        Right
    
    '''
    
    TOP_LEFT = 0
    TOP_RIGHT = 1
    BOTTOM_LEFT = 2
    BOTTOM_RIGHT = 3    


class CellEnum(Enum):
    '''
                                                          N            
                                                          _
    Below cardial directions represents the four walls W |_| E  of a cell

                                                          S    
    '''    
    NORTH = 8
    EAST  = 4
    WEST  = 2
    SOUTH = 1

class Maze1(Enum):    

    # MAZE 1's  min and maximum column and rows
    JSON_FILE_MAZE_1_DATA = "maze_data_one.json"
    MAX_CELL_ROW = 10
    MAX_CELL_COL = 10    
    ENTRY_ROW = 0
    ENTRY_COL = 4
    ENTRY_WALL = CellEnum.NORTH.value


'''
TODO FUTURE MAZES
'''
class FileEnum(Enum):

    # Below constants will hold the make file names    
    JSON_FILE_MAZE_2_DATA = 'MAZE_DATA_2.json'
    JSON_FILE_MAZE_3_DATA = 'MAZE_DATA_3.json'

    # format of the files to check while reading the file
    FORMAT_JSON = 0
    FORMAT_CSV = 1
    
