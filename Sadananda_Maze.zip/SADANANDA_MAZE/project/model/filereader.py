import os
import json

class FileReader:

    def __init__(self , file_name_location : str = ''):
        self._file_name_location = file_name_location                            
    
    def _is_file_exist(self):
        
        self._file_name_location = self._get_absolute_file_path()
        isExist = os.path.exists(self._file_name_location)                        
        return isExist
        
    def _get_absolute_file_path(self):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(script_dir, self._file_name_location) 
        return file_path
        
        

class JsonFileReader(FileReader):

    def __init__(self , file_name):      
        super().__init__(file_name)    
    
    def get_json_file_data(self):

        if self._is_file_exist():
            try:
                with open(self._file_name_location , 'r') as f:
                    self.data = json.load(f)
            except FileNotFoundError:
                print('File Path Not Found')
        else:
            raise FileNotFoundError                
            
        return self.data