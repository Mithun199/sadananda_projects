Project description: This is an maze solver project.
					 Input to this is provided to json file and and it is an dictionary with integer values which represents walls
					 example : consider value in json file = 15 which is 0xF it signified all the walls are present in N E W S direction
							   if value is 12 which is hex = 0xC N E W S here west and south walls are absent.
					This will draw the maze in tkinter canvas and will solve the path for the same which is rendered in RED

Installation: 
			python >= 3.7
			tkinter

Execution and usage: 
			python main.py

Used technologies: 
			None

Current features: 
			Focuses on solving 2-D maze with any number of rows and columns	

Contributors: 
		Thejaswini S
			

Author’s info: 
		Mithun V
		
Release Date:
		07/28/2024

License: 
	Copyright @3285 Sadananda Maharaj
		