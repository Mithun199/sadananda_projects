# Import the required libraries
from tkinter import *
import sys
sys.path.append('..')
from model import *

class DrawWidget:
    def __init__(self , _width , _height):
        # Create an instance of tkinter frame or window
        self.win=Tk()
        # Set the size of the tkinter window
        self.win.geometry(MazeBoardEnum.MAZE_WITDH_HEIGTH.value)
        # Set the Title
        self.win.title("Sadananda MAZE")
        
        # Create a canvas widget
        self.canvas=Canvas(self.win, width=_width, height=_height)
        self.canvas.pack()

    def render_widget(self):
        self.win.mainloop()
    
class DrawLine(DrawWidget):

    def __init__(self , _width=MazeBoardEnum.CANVAS_WIDTH.value , _height=MazeBoardEnum.CANVAS_HEIGTH.value):
        super().__init__(_width , _height)
                
    # draw the line from point_1 to point_2 this would internally call the standard tkinter function
    def draw_line(self , point_1 , point_2 , color=MazeBoardEnum.MAZE_LINE_COLOR.value , render=False):
        # Add a line in canvas widget
        self.canvas.create_line(point_1[0] , point_1[1] ,
                                point_2[0] ,  point_2[1] ,
                                fill=color ,  width=MazeBoardEnum.MAZE_LINE_WIDTH.value)
        if render:            
            super().render_widget()            

        



    
