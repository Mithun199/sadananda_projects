class SolveMaze:

    @staticmethod
    def find_maze_path(cur_cell , entry_wall , path):    
                    
        cur_cell.N_E_W_S_covered = cur_cell.N_E_W_S_covered ^ entry_wall
                
        if (len(path) != 0):

            if cur_cell.row == 0:
                if ( ~ cur_cell.N_E_W_S_covered ) & (CellEnum.NORTH.value):
                    Cell.PATH_FOUND = True
                    path.append((cur_cell.row , cur_cell.col))
                    return
            if cur_cell.row == 9:
                if ( ~ cur_cell.N_E_W_S_covered ) & (CellEnum.SOUTH.value):
                    Cell.PATH_FOUND = True
                    path.append((cur_cell.row , cur_cell.col))
                    return
            if cur_cell.col == 0:
                if ( ~ cur_cell.N_E_W_S_covered ) & (CellEnum.WEST.value):
                    Cell.PATH_FOUND = True
                    path.append((cur_cell.row , cur_cell.col))
                    return
            if cur_cell.col == 9:
                if ( ~ cur_cell.N_E_W_S_covered ) & (CellEnum.EAST.value):
                    Cell.PATH_FOUND = True
                    path.append((cur_cell.row , cur_cell.col))
                    return
        
        if ( ~ cur_cell.N_E_W_S_covered ) & CellEnum.NORTH.value:            
            print('NORTH')
            next_cell_detail = get_next_cell_details(CellEnum.NORTH.value , cur_cell.row , cur_cell.col)
            row , col = next_cell_detail[1][0] , next_cell_detail[1][1]        
            next_cell = n[row][col]     
            cur_cell.N_E_W_S_covered = cur_cell.N_E_W_S_covered ^ CellEnum.NORTH.value        
            path.append((cur_cell.row , cur_cell.col))        
            find_maze_path(next_cell , next_cell_detail[0].value , path)                    
            if Cell.PATH_FOUND == True:            
                return
            else:
                path.pop()            
        
        if ( ~ cur_cell.N_E_W_S_covered ) & CellEnum.SOUTH.value:            
            print('SOUTH')
            next_cell_detail = get_next_cell_details(CellEnum.SOUTH.value , cur_cell.row , cur_cell.col)
            row , col = next_cell_detail[1][0] , next_cell_detail[1][1]        
            next_cell = n[row][col]     
            cur_cell.N_E_W_S_covered = cur_cell.N_E_W_S_covered ^ CellEnum.SOUTH.value        
            path.append((cur_cell.row , cur_cell.col))        
            find_maze_path(next_cell , next_cell_detail[0].value , path)        
            if Cell.PATH_FOUND == True:            
                return
            else:            
                path.pop()
                
        if ( ~ cur_cell.N_E_W_S_covered ) & CellEnum.EAST.value:                    
            print('EAST')
            next_cell_detail = get_next_cell_details(CellEnum.EAST.value , cur_cell.row , cur_cell.col)
            row , col = next_cell_detail[1][0] , next_cell_detail[1][1]        
            next_cell = n[row][col]     
            cur_cell.N_E_W_S_covered = cur_cell.N_E_W_S_covered ^ CellEnum.EAST.value        
            path.append((cur_cell.row , cur_cell.col))        
            find_maze_path(next_cell , next_cell_detail[0].value , path)        
            if Cell.PATH_FOUND == True:            
                return
            else:            
                path.pop()
        
        if ( ~ cur_cell.N_E_W_S_covered ) & CellEnum.WEST.value:                    
            print('WEST')
            next_cell_detail = get_next_cell_details(CellEnum.WEST.value , cur_cell.row , cur_cell.col)
            row , col = next_cell_detail[1][0] , next_cell_detail[1][1]        
            next_cell = n[row][col]     
            cur_cell.N_E_W_S_covered = cur_cell.N_E_W_S_covered ^ CellEnum.WEST.value        
            path.append((cur_cell.row , cur_cell.col))        
            find_maze_path(next_cell , next_cell_detail[0].value , path)        
            if Cell.PATH_FOUND == True:            
                return
            else:                        
                path.pop()     
        
        return    
