import sys
sys.path.append('..')
from view import *
from model import *
from controller import *

class SolveMaze:

    def __init__(self , _cells):
        self.cells = _cells        
                
    def find_maze_path(self , cur_cell , entry_wall , path):    
            
        '''
            This is an backtracking function which will find the maze path using recurrssion 
        
        Args :
            cur_cell : This is the open cell i.e the entry path of the maze from which we need to start and reach the end door
            entry_wall : This specifies the wall from which we made an entry to the cur_cell .
                         which is nothing but open door in the entry or 1st cell from where we need to start.
            path : Empty list which is passed to store the maze path
        
        return :
        
        '''
        cur_cell.N_E_W_S_covered = cur_cell.N_E_W_S_covered ^ entry_wall                        
                
        if (len(path) != 0):
            
            
            if cur_cell.row == 0:
                if ( ~ cur_cell.N_E_W_S_covered ) & (CellEnum.NORTH.value):
                    Cell.PATH_FOUND = True
                    path.append((cur_cell.row , cur_cell.col))
                    return
            if cur_cell.row == 9:
                if ( ~ cur_cell.N_E_W_S_covered ) & (CellEnum.SOUTH.value):
                    Cell.PATH_FOUND = True
                    path.append((cur_cell.row , cur_cell.col))
                    return
            if cur_cell.col == 0:
                if ( ~ cur_cell.N_E_W_S_covered ) & (CellEnum.WEST.value):
                    Cell.PATH_FOUND = True
                    path.append((cur_cell.row , cur_cell.col))
                    return
            if cur_cell.col == 9:
                if ( ~ cur_cell.N_E_W_S_covered ) & (CellEnum.EAST.value):
                    Cell.PATH_FOUND = True
                    path.append((cur_cell.row , cur_cell.col))
                    return

            # check the wall openings with & logic just to enter into the next cell
        if ( ~ cur_cell.N_E_W_S_covered ) & CellEnum.NORTH.value:            
            print('NORTH')
            # Next cell which has path opened for further navigation
            # Exit of this cell's wall is entry to next cell.
                # example below
                #   current cell exit wall is SOUTH
                #   next cell entry wall is NORTH 
            next_cell_detail = get_next_cell_details(CellEnum.NORTH.value , cur_cell.row , cur_cell.col)
            row , col = next_cell_detail[1][0] , next_cell_detail[1][1]        
            next_cell = self.cells[row][col]     
            # once you entered the cell through any wall , mark that wall as it is already travelled. 
            cur_cell.N_E_W_S_covered = cur_cell.N_E_W_S_covered ^ CellEnum.NORTH.value        
            path.append((cur_cell.row , cur_cell.col))        
            self.find_maze_path(next_cell , next_cell_detail[0].value , path)                    
            if Cell.PATH_FOUND == True:            
                return
            else:
                # if the current cell is not the end cell or the exit wall then remove the recently added wall
                path.pop()            
        
        if ( ~ cur_cell.N_E_W_S_covered ) & CellEnum.SOUTH.value:            
            print('SOUTH')
            next_cell_detail = get_next_cell_details(CellEnum.SOUTH.value , cur_cell.row , cur_cell.col)
            row , col = next_cell_detail[1][0] , next_cell_detail[1][1]        
            next_cell = self.cells[row][col]     
            cur_cell.N_E_W_S_covered = cur_cell.N_E_W_S_covered ^ CellEnum.SOUTH.value        
            path.append((cur_cell.row , cur_cell.col))        
            self.find_maze_path(next_cell , next_cell_detail[0].value , path)        
            if Cell.PATH_FOUND == True:            
                return
            else:            
                path.pop()
                
        if ( ~ cur_cell.N_E_W_S_covered ) & CellEnum.EAST.value:                    
            print('EAST')
            next_cell_detail = get_next_cell_details(CellEnum.EAST.value , cur_cell.row , cur_cell.col)
            row , col = next_cell_detail[1][0] , next_cell_detail[1][1]        
            next_cell = self.cells[row][col]     
            cur_cell.N_E_W_S_covered = cur_cell.N_E_W_S_covered ^ CellEnum.EAST.value        
            path.append((cur_cell.row , cur_cell.col))        
            self.find_maze_path(next_cell , next_cell_detail[0].value , path)        
            if Cell.PATH_FOUND == True:            
                return
            else:            
                path.pop()
        
        if ( ~ cur_cell.N_E_W_S_covered ) & CellEnum.WEST.value:                    
            print('WEST')
            next_cell_detail = get_next_cell_details(CellEnum.WEST.value , cur_cell.row , cur_cell.col)
            row , col = next_cell_detail[1][0] , next_cell_detail[1][1]        
            next_cell = self.cells[row][col]     
            cur_cell.N_E_W_S_covered = cur_cell.N_E_W_S_covered ^ CellEnum.WEST.value        
            path.append((cur_cell.row , cur_cell.col))        
            self.find_maze_path(next_cell , next_cell_detail[0].value , path)        
            if Cell.PATH_FOUND == True:            
                return
            else:                        
                path.pop()     
        
        return    


class Maze:
    
    def __init__(self , _maze):              
        self.eMaze = _maze
        self.cells = list()        
        self.max_row_col = 0
        self.path = list()
    
    def build_maze(self):   
        '''
            Read the Json file which has the maze wall details
        '''
        
        json_reader = JsonFileReader(self.eMaze.JSON_FILE_MAZE_1_DATA.value)
        data = json_reader.get_json_file_data()

        # fill all the data into the cell object along with rows and cols
        m = list()          
        for row in range(0 , self.eMaze.MAX_CELL_ROW.value):
            for col in range(0 , self.eMaze.MAX_CELL_COL.value):
                k = Cell(row , col)
                k.N_E_W_S = data[row][col]
                m.append(k)            
            self.cells.append(m.copy())               
            m.clear()            

    def solve_maze(self):
        
        _solve_maze = SolveMaze(self.cells)                
        _solve_maze.find_maze_path(self.cells[self.eMaze.ENTRY_ROW.value][self.eMaze.ENTRY_COL.value] , self.eMaze.ENTRY_WALL.value , self.path)                        
        
        maze = DrawLine()                
        self._draw_maze(maze)
        self._draw_maze(maze , self.path , True ,  MazeBoardEnum.MAZE_PATH_INITIAL_X.value)                                                        
                    
    def _draw_maze(self , maze , path=list() , _render=False , maze_initial_x_position=0):     
    
        '''
            This method will draw the maze with given WALL (N_E_W_S) data
            
            Args:
                maze : It's a maze canvas widget on which the maze is drawn
                path : maze path which is solved by the backtracking function 'find_maze_path'
                _render : this parameter is to render the maze on canvas or not 
                maze_initial_x_position : initial x position of the maze from the right size
                
            return 
                None
        
        '''
    
        # This logic will draw the maze on the canvas
        for row in self.cells:   
            for _cell in row:                
                wall_cordinates = get_wall_cordinates(_cell)              
                for index , wall in enumerate(CellEnum):
                    if _cell.N_E_W_S & wall.value:                                     
                    
                        x_y = (wall_cordinates[index][0][0] + maze_initial_x_position , wall_cordinates[index][0][1])
                        x1_y1 = (wall_cordinates[index][1][0] + maze_initial_x_position , wall_cordinates[index][1][1])                       
                        maze.draw_line(x_y , x1_y1)

        # This will draw the maze which has the 'SOLVED PATH' in it with RED path , this maze is drawn with extra width to maze on left
        for row in self.cells:   
            for _cell in row:                
                wall_cordinates = get_wall_cordinates(_cell)               
                for index , wall in enumerate(CellEnum):
                    if (_cell.N_E_W_S & wall.value) and ((_cell.row , _cell.col) in path):                            
                        x_y = (wall_cordinates[index][0][0] + maze_initial_x_position , wall_cordinates[index][0][1])
                        x1_y1 = (wall_cordinates[index][1][0] + maze_initial_x_position , wall_cordinates[index][1][1])                       
                        maze.draw_line(x_y , x1_y1  , color=MazeBoardEnum.MAZE_PATH_COLOR.value)                                                        
                    
        maze.draw_line(x_y , x1_y1 , color=MazeBoardEnum.MAZE_PATH_COLOR.value , render=_render)